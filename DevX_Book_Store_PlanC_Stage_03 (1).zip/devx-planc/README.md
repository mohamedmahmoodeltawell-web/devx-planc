# Dev-X Book Store — Plan C

Full-stack rebuild (Next.js 15 + TypeScript + Prisma/PostgreSQL) of the single-file store UI preserved in `reference/original-ui/`.
**Stage 2 status: BLOCKED at the verification gate (npm registry unreachable; no new features). Stage 1: PARTIAL.** See `docs/project/STAGE_02_REPORT.md`. Interim DB reconciliation: `PGURL=postgresql://USER@HOST:PORT/DB python3 scripts/check_schema_vs_db.py`.

**Stage 1 status: PARTIAL** — foundation, docs, schema, migration, pricing engine + tests done; `npm install`/build never run (registry blocked in the sandbox). See `docs/project/HANDOFF.md`.

## Layout
`reference/` original UI + extracted seed/assets (read-only) · `prisma/` schema + migrations · `src/` app (`app/`, `lib/`, `server/`) · `tests/` · `scripts/` · `docs/project/` all project docs.

## Commands
| Task | Command | Needs |
|---|---|---|
| Install | `npm install` (commit lockfile) | npm registry |
| Dev / build / start | `npm run dev` · `npm run build` · `npm start` | install + `.env` |
| Typecheck / lint | `npm run typecheck` · `npm run lint` | install |
| Tests | `npm test` (= `tsx --test tests/*.test.ts`) | `tsx`, Node ≥ 20 |
| Re-extract reference data | `npm run extract:reference` | Node only |
| DB | `npm run db:validate` · `db:generate` · `db:migrate:dev` · `db:migrate:deploy` | Prisma + PostgreSQL |
| Verify SQL migration | `PSQL_URL=postgresql://USER@HOST:PORT npm run db:verify` | psql + server |

Copy `.env.example` → `.env` (never commit it).
