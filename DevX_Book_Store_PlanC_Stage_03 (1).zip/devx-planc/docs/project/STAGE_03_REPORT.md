# Stage 3 report — server features (executed in a sandbox WITHOUT npm registry access)

## Verification status (what actually ran)
| Check | Result |
|---|---|
| `tsx --test tests/*.test.ts` | **29/29 pass** (15 pre-existing + 14 new: auth, sessions, rate limit, order creation, rollback, payment gating, transitions, validators) |
| `tsc` on server/lib/API routes/tests/scripts with `tsconfig.check.json` (Prisma client **stubbed**, @types/node real) | **0 errors** |
| esbuild syntax parse of all 73 `src/**/*.ts(x)` files | 0 errors |
| `scripts/import-catalog.ts` dry run | 69/69 valid, no DB contact |
| `npm ci`, `prisma validate/generate`, `next lint`, `next build`, React/TSX type-check | **NOT RUN** — registry blocked (HTTP 403 via proxy). **Run these locally first**: `npm ci && npx prisma validate && npm run lint && npm run typecheck && npm test && npm run build` |
| Any Supabase access / write / migration / import / deployment | **None performed** |

## Prisma sync (schema only, no migration file created)
`prisma/schema.prisma` now has `PaymentMethodCode` + `VODAFONE_CASH, ORANGE_CASH, ETISALAT_CASH`, enum `PaymentConfigStatus` (6 verified values), and `PaymentMethodConfig.status` / `integrationNotes`.
**Assumption to confirm:** column defaults (`NOT_CONFIGURED`, `""`) were not provided. Run `scripts/readonly-db-checks.sql` (SELECT-only) and compare query 3. The payment migration `20261011180000_payment_method_status_and_wallets` is NOT in the repo; none was invented. `_prisma_migrations` has only `init`, so `prisma migrate deploy/dev` will see drift — decide with the owner between (a) recreating that migration from the verified live DDL and `migrate resolve --applied`, or (b) a baseline. Do not run either before verifying query 1–3 output.

## API (all under `/api/v1`, JSON `{ok, ...}` / `{ok:false,error:{code,message}}`)
| Method & path | Auth | Notes |
|---|---|---|
| GET `/health` | – | liveness |
| GET `/products?page&pageSize&category&q&sort&offers&available` | – | paginated (max 48), active only, safe fields |
| GET `/products/:id` | – | by id or legacyId |
| GET `/categories`, `/branches`, `/payment-methods` | – | payment methods: only COD (enabled) and online methods with status READY |
| POST `/cart/quote` | – | server prices; no client totals accepted |
| POST `/auth/register` `/auth/login` `/auth/logout`, GET `/auth/me` | – | scrypt hashes, HMAC-signed HttpOnly SameSite=Lax cookie, rate limited; role always CUSTOMER on register, read from DB per request |
| POST/GET `/orders`, GET `/orders/:id`, POST `/orders/:id/payment` | user | ownership in query (no IDOR); one transaction: server quote → conditional stock decrement → coupon consume → order + snapshot + history; always `AWAITING_PAYMENT`; a reference only moves it to `PENDING_REVIEW` |
| GET `/admin/orders`, GET/PATCH `/admin/orders/:id` | STAFF/ADMIN | explicit transition table; prepaid orders cannot be prepared before PAID; cancel restores stock; audit log |
| PATCH `/admin/payments/:id` | ADMIN | only path that sets PAID (amount must match) |
| GET/POST `/admin/products`, PATCH `/admin/products/:id`, POST `/admin/categories` | ADMIN | new products are always inactive |
| GET `/admin/payment-methods`, PATCH `/admin/payment-methods/:code` | ADMIN | READY for non-COD requires documented notes |

## Pages added
`/login /register /account /checkout /orders /orders/[id] /admin /product/[id] /category/[id] /policy/[key]` (the last three were empty folders — links from the home page 404'd before). Product/category pages still read the **demo `catalog.json`**; DB-backed storefront switch-over belongs after the owner-approved import.

## Known limits / open items
- **Not done:** Arabic/English toggle (UI is Arabic-RTL only), e-book entitlements + protected downloads (needs new tables → migration), wishlist/reviews/support/password-recovery UIs, governorate/delivery-area tables, real gateway adapters (Fawry/InstaPay/wallets) and webhooks — require merchant credentials/official docs; every online method stays unselectable until an admin sets READY.
- Sessions are stateless (no Session table exists): logout clears the cookie; password change invalidates old sessions; rate limiter is in-memory per instance (use Redis for multi-instance).
- Fixed `SESSION_SECRET` (>=32 chars) is required or auth endpoints fail closed.
- Admin bootstrap: `scripts/create-admin.ts` (dry-run default; `--apply` writes ONE user). Catalog import: `scripts/import-catalog.ts` (dry-run default; `--apply` imports inactive, stock 0). Neither has been run.
- Existing 1–2 piaster rounding drift vs original UI (documented D-014) unchanged.
