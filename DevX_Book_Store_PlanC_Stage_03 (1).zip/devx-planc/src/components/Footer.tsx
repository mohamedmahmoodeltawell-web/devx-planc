import Link from 'next/link';
import { policies } from '../lib/catalog';

export function Footer() {
  return (
    <footer id="foot" className="foot">
      <div className="foot-in">
        <div className="foot-col foot-brand"><b>Dev-X Book Store</b><p>كتب وتيشرتات ونوت بوك ومنتجات متنوعة لعشاق التعلّم والتقنية.</p></div>
        <div className="foot-col"><h4>روابط مهمة</h4><Link href="/categories">الأقسام</Link><Link href="/search?offers=1">العروض</Link><Link href="/cart">السلة</Link><Link href="/orders">طلباتي</Link></div>
        <div className="foot-col"><h4>السياسات</h4>{Object.entries(policies).map(([k, v]) => <Link key={k} href={`/policy/${k}`}>{v.title}</Link>)}</div>
      </div>
      <div className="foot-bot"><span>© {new Date().getFullYear()} Dev-X Book Store — جميع الحقوق محفوظة</span></div>
    </footer>
  );
}
