'use client';
import Link from 'next/link';
import { useMemo } from 'react';
import { cartKey } from '../lib/cart';
import { quoteCart } from '../lib/storefront';
import { formatPriceAr } from '../lib/money';
import { useCart } from './CartProvider';
import { Empty } from './ProductCard';
import { Icon } from './Icon';

export function CartView() {
  const { cart, loaded, change, remove } = useCart();
  const q = useMemo(() => quoteCart(cart), [cart]);
  if (!loaded) return <div className="spin" role="status">جاري التحميل…</div>;
  if (!cart.length) return <Empty title="سلتك فارغة" text="أضف منتجات لتظهر هنا." href="/categories" action="تصفّح الأقسام" />;
  return (
    <>
      {q.errors.map((e, i) => <div key={i} className="msg err" role="alert"><Icon name="x" /> {e.message}</div>)}
      <div className="layout2">
        <div className="card">
          {cart.map((i) => {
            const k = cartKey(i), l = q.lines.find((x) => cartKey(x) === k);
            return l ? (
              <div className="line" key={k}>
                <div className="t"><Link href={`/product/${l.productId}`}><b>{l.name}</b></Link><span className="muted">{[l.size, l.color].filter(Boolean).join(' · ')}</span>
                  <div><span className={`price${l.unitSale < l.unitOriginal ? ' sale' : ''}`}>{formatPriceAr(l.unitSale)}</span>{l.unitSale < l.unitOriginal && <span className="old">{formatPriceAr(l.unitOriginal)}</span>}</div></div>
                <div className="qty"><button type="button" aria-label="إنقاص" onClick={() => change(k, -1)}>−</button><span>{i.qty}</span><button type="button" aria-label="زيادة" onClick={() => change(k, 1)}>+</button></div>
                <b>{formatPriceAr(l.lineSale)}</b>
                <button type="button" className="btn secondary sm" aria-label="حذف" onClick={() => remove(k)}>حذف</button>
              </div>
            ) : <div className="line" key={k}><div className="t"><div className="msg err"><Icon name="x" /> عنصر لم يعد متاحًا</div></div><button type="button" className="btn secondary sm" onClick={() => remove(k)}>حذف</button></div>;
          })}
        </div>
        <div>
          <div className="summary"><h3>ملخص الطلب</h3><dl>
            <div className="l"><span>إجمالي المنتجات قبل الخصومات</span><span>{formatPriceAr(q.subtotalOriginal)}</span></div>
            {q.productDiscounts > 0 && <div className="l save"><span>خصومات المنتجات</span><span>− {formatPriceAr(q.productDiscounts)}</span></div>}
            {q.tierDiscount > 0 && <div className="l save"><span>خصم إجمالي الطلب ({q.tierRate}٪)</span><span>− {formatPriceAr(q.tierDiscount)}</span></div>}
            <div className="l total"><span>المبلغ النهائي</span><span>{formatPriceAr(q.total)}</span></div></dl>
            <small>خصم الشريحة يُحسب على الإجمالي بعد خصومات المنتجات. الشحن وكود الخصم يُحسبان عند إتمام الطلب.</small></div>
          <p><Link className="btn" href="/checkout" style={{ width: '100%' }}>إتمام الطلب</Link></p>
          <div className="msg warn" role="status"><Icon name="alert" /> السلة محفوظة على جهازك. الأسعار والمخزون النهائيان يتحققان منهما الخادم عند إتمام الطلب، ويلزم تسجيل الدخول.</div>
        </div>
      </div>
    </>
  );
}
