'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { api } from '../lib/api';
import { CONFIG_STATUS_AR, dt, NEXT_STATUSES, ORDER_STATUS_AR, PAYMENT_METHOD_AR, PAYMENT_STATUS_AR } from '../lib/labels';
import { formatPriceAr } from '../lib/money';

type Tab = 'orders' | 'payments' | 'products';
interface OrderRow { id: string; number: number; customerName: string; customerPhone: string; status: string; paymentStatus: string; paymentMethod: string; total: number; createdAt: string }
interface OrderFull extends OrderRow { items: { id: string; name: string; qty: number; lineSale: number }[]; payments: { id: string; method: string; reference: string; senderPhone: string; status: string; amount: number }[] }
interface Cfg { code: string; name: string; enabled: boolean; status: string; integrationNotes: string }
interface Prod { id: string; name: string; price: number; salePrice: number | null; active: boolean; category: { name: string }; variants: { id: string; size: string; color: string; stock: number }[] }
const STATUSES = Object.keys(CONFIG_STATUS_AR);

export function AdminPanel() {
  const [role, setRole] = useState<string | null | undefined>(undefined);
  const [tab, setTab] = useState<Tab>('orders');
  useEffect(() => { void api<{ user: { role: string } | null }>('/api/v1/auth/me').then((r) => setRole(r.ok ? r.data.user?.role ?? null : null)); }, []);
  if (role === undefined) return <div className="spin" role="status">جاري التحميل…</div>;
  if (role !== 'ADMIN' && role !== 'STAFF') return <div className="card"><h1>لوحة الإدارة</h1><p>هذه الصفحة للمصرّح لهم فقط.</p><Link className="btn" href="/login?next=/admin">تسجيل الدخول</Link></div>;
  return (
    <div className="card">
      <h1>لوحة الإدارة</h1>
      <div className="tabs" role="tablist">{(['orders', 'payments', 'products'] as Tab[]).filter((t) => role === 'ADMIN' || t === 'orders').map((t) => <button key={t} type="button" role="tab" aria-selected={tab === t} className="btn ghost sm" onClick={() => setTab(t)}>{t === 'orders' ? 'الطلبات' : t === 'payments' ? 'وسائل الدفع' : 'المنتجات'}</button>)}</div>
      {tab === 'orders' && <Orders isAdmin={role === 'ADMIN'} />}
      {tab === 'payments' && role === 'ADMIN' && <Payments />}
      {tab === 'products' && role === 'ADMIN' && <Products />}
    </div>
  );
}

function Orders({ isAdmin }: { isAdmin: boolean }) {
  const [rows, setRows] = useState<OrderRow[] | null>(null);
  const [sel, setSel] = useState<OrderFull | null>(null);
  const [filter, setFilter] = useState('');
  const [msg, setMsg] = useState('');
  const load = useCallback(() => api<{ orders: OrderRow[] }>(`/api/v1/admin/orders${filter ? `?paymentStatus=${filter}` : ''}`).then((r) => setRows(r.ok ? r.data.orders : [])), [filter]);
  useEffect(() => { void load(); }, [load]);
  const open = (id: string) => api<{ order: OrderFull }>(`/api/v1/admin/orders/${id}`).then((r) => r.ok && setSel(r.data.order));
  async function setStatus(status: string) { if (!sel) return; const r = await api(`/api/v1/admin/orders/${sel.id}`, { method: 'PATCH', body: { status } }); setMsg(r.ok ? 'تم التحديث.' : r.message); void open(sel.id); void load(); }
  async function review(id: string, decision: 'ACCEPT' | 'REJECT') { if (!sel || !window.confirm(decision === 'ACCEPT' ? 'تأكيد أنك تحققت من وصول المبلغ فعليًا؟' : 'رفض هذه الدفعة؟')) return; const r = await api(`/api/v1/admin/payments/${id}`, { method: 'PATCH', body: { decision } }); setMsg(r.ok ? 'تم.' : r.message); void open(sel.id); void load(); }
  return <>
    <label>تصفية حسب الدفع<select value={filter} onChange={(e) => setFilter(e.target.value)}><option value="">الكل</option>{Object.entries(PAYMENT_STATUS_AR).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
    {msg && <div className="msg ok" role="status">{msg}</div>}
    {!rows ? <div className="spin" role="status">جاري التحميل…</div> : <div className="tblwrap"><table className="t"><thead><tr><th>#</th><th>العميل</th><th>الحالة</th><th>الدفع</th><th>الإجمالي</th><th /></tr></thead><tbody>
      {rows.map((o) => <tr key={o.id}><td>DX-{o.number}</td><td>{o.customerName}<br /><span className="muted" dir="ltr">{o.customerPhone}</span></td><td>{ORDER_STATUS_AR[o.status]}</td><td>{PAYMENT_METHOD_AR[o.paymentMethod]} · {PAYMENT_STATUS_AR[o.paymentStatus]}</td><td>{formatPriceAr(o.total)}</td><td><button type="button" className="btn ghost sm" onClick={() => void open(o.id)}>فتح</button></td></tr>)}
      {rows.length === 0 && <tr><td colSpan={6}>لا توجد طلبات.</td></tr>}</tbody></table></div>}
    {sel && <div className="card" style={{ marginTop: '1rem' }}>
      <h3>DX-{sel.number} — {dt(sel.createdAt)}</h3>
      <ul>{sel.items.map((i) => <li key={i.id}>{i.name} × {i.qty} — {formatPriceAr(i.lineSale)}</li>)}</ul>
      <div className="rowbtns">{NEXT_STATUSES[sel.status]?.map((s) => <button key={s} type="button" className={s === 'CANCELLED' ? 'btn secondary sm' : 'btn sm'} onClick={() => void setStatus(s)}>{ORDER_STATUS_AR[s]}</button>)}</div>
      {sel.payments.length > 0 && <><h3>دفعات مُرسلة</h3><ul>{sel.payments.map((p) => <li key={p.id}><span dir="ltr">{p.reference}</span> · {PAYMENT_METHOD_AR[p.method]} · {formatPriceAr(p.amount)} · {p.status}{isAdmin && p.status === 'SUBMITTED' && <span className="rowbtns"><button type="button" className="btn sm" onClick={() => void review(p.id, 'ACCEPT')}>تأكيد الدفع</button><button type="button" className="btn secondary sm" onClick={() => void review(p.id, 'REJECT')}>رفض</button></span>}</li>)}</ul></>}
    </div>}
  </>;
}

function Payments() {
  const [rows, setRows] = useState<Cfg[] | null>(null);
  const [msg, setMsg] = useState('');
  const load = () => api<{ methods: Cfg[] }>('/api/v1/admin/payment-methods').then((r) => setRows(r.ok ? r.data.methods : []));
  useEffect(() => { void load(); }, []);
  async function save(e: FormEvent<HTMLFormElement>, code: string) {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const r = await api(`/api/v1/admin/payment-methods/${code}`, { method: 'PATCH', body: { status: String(f.get('status')), enabled: f.get('enabled') === 'on', integrationNotes: String(f.get('notes') ?? '') } });
    setMsg(r.ok ? 'تم الحفظ.' : r.message); void load();
  }
  if (!rows) return <div className="spin" role="status">جاري التحميل…</div>;
  return <>
    <div className="msg warn">لا تجعل أي وسيلة «جاهز» قبل اكتمال التكامل الرسمي واختبار التحقق من الدفع، ووثّق ذلك في الملاحظات.</div>
    {msg && <div className="msg ok" role="status">{msg}</div>}
    {rows.map((c) => <form key={c.code} onSubmit={(e) => void save(e, c.code)} className="card" style={{ marginBottom: '.8rem' }}>
      <h3>{PAYMENT_METHOD_AR[c.code] ?? c.name}</h3>
      <label>الحالة<select name="status" defaultValue={c.status}>{STATUSES.map((s) => <option key={s} value={s}>{CONFIG_STATUS_AR[s]}</option>)}</select></label>
      <label className="radio"><input type="checkbox" name="enabled" defaultChecked={c.enabled} /> مفعّلة في المتجر</label>
      <label>ملاحظات التكامل / طريقة التحقق<textarea name="notes" defaultValue={c.integrationNotes} maxLength={2000} /></label>
      <p><button className="btn sm" type="submit">حفظ</button></p></form>)}
  </>;
}

function Products() {
  const [rows, setRows] = useState<Prod[] | null>(null);
  const [msg, setMsg] = useState('');
  const load = () => api<{ products: Prod[] }>('/api/v1/admin/products').then((r) => setRows(r.ok ? r.data.products : []));
  useEffect(() => { void load(); }, []);
  async function patch(id: string, body: unknown) { const r = await api(`/api/v1/admin/products/${id}`, { method: 'PATCH', body }); setMsg(r.ok ? 'تم الحفظ.' : r.message); void load(); }
  async function save(e: FormEvent<HTMLFormElement>, p: Prod) {
    e.preventDefault(); const f = new FormData(e.currentTarget), egp = (k: string) => Math.round(Number(f.get(k)) * 100);
    const sale = String(f.get('sale') ?? '').trim();
    await patch(p.id, { price: egp('price'), salePrice: sale ? egp('sale') : null, variants: p.variants.map((v) => ({ id: v.id, stock: Number(f.get(`s_${v.id}`)) })) });
  }
  if (!rows) return <div className="spin" role="status">جاري التحميل…</div>;
  return <>
    {msg && <div className="msg ok" role="status">{msg}</div>}
    {rows.length === 0 && <div className="msg warn">لا توجد منتجات في قاعدة البيانات بعد. الاستيراد يتم بعد مراجعة واعتماد المالك.</div>}
    {rows.map((p) => <form key={p.id} onSubmit={(e) => void save(e, p)} className="card" style={{ marginBottom: '.8rem' }}>
      <h3>{p.name} <span className={`badge ${p.active ? 'ver' : 'out'}`}>{p.active ? 'منشور' : 'غير منشور'}</span></h3>
      <div className="filters"><div><label>السعر (ج.م)<input name="price" type="number" step="0.01" min="0.01" defaultValue={p.price / 100} required /></label></div>
        <div><label>سعر التخفيض (اختياري)<input name="sale" type="number" step="0.01" min="0.01" defaultValue={p.salePrice != null ? p.salePrice / 100 : ''} /></label></div></div>
      {p.variants.map((v) => <label key={v.id}>مخزون {[v.size, v.color].filter(Boolean).join(' · ') || 'الافتراضي'}<input name={`s_${v.id}`} type="number" min="0" step="1" defaultValue={v.stock} required /></label>)}
      <div className="rowbtns"><button className="btn sm" type="submit">حفظ</button>
        <button type="button" className="btn ghost sm" onClick={() => { if (!p.active && !window.confirm('نشر المنتج للعملاء بهذا السعر والمخزون؟')) return; void patch(p.id, { active: !p.active }); }}>{p.active ? 'إلغاء النشر' : 'نشر'}</button></div>
    </form>)}
  </>;
}
