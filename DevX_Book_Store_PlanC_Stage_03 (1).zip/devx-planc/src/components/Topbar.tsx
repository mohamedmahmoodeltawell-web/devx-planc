'use client';
import Link from 'next/link';
import type { CSSProperties } from 'react';
import { Icon } from './Icon';
import { useCart } from './CartProvider';

export function Topbar() {
  const { count } = useCart();
  return (
    <header className="topbar">
      <Link href="/" className="logo" aria-label="Dev-X Book Store">
        <b aria-hidden="true">{['D', 'e', 'v', '-', 'X'].map((ch, i) => <i key={i} className={i >= 2 ? 'x' : undefined} style={{ '--i': i } as CSSProperties}>{ch}</i>)}</b>
        <span aria-hidden="true">{[...'BOOK STORE'].map((ch, i) => <i key={i} style={{ '--j': i } as CSSProperties}>{ch === ' ' ? ' ' : ch}</i>)}</span>
      </Link>
      <form className="topsearch" role="search" action="/search" method="get">
        <Icon name="search" />
        <input name="q" type="search" placeholder="ابحث عن كتاب أو تيشرت أو نوت بوك…" aria-label="بحث" />
      </form>
      <Link href="/cart" className="icon-btn cart-link" aria-label="السلة"><Icon name="cart" />{count > 0 && <b>{count}</b>}</Link>
    </header>
  );
}
