'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Icon } from './Icon';
import { useCart } from './CartProvider';

const LIVE: [string, string, string][] = [['/', 'home', 'الرئيسية'], ['/categories', 'grid', 'الأقسام'], ['/search?offers=1', 'tag', 'العروض'], ['/search', 'search', 'البحث'], ['/cart', 'cart', 'السلة'], ['/orders', 'box', 'طلباتي'], ['/account', 'user', 'حسابي'], ['/login', 'key', 'تسجيل الدخول']];
// Backend-dependent pages from the original UI: NOT implemented yet — shown disabled, never as working links.
const SOON: [string, string][] = [['pin', 'الفروع'], ['card', 'الدفع'], ['chat', 'الدعم']];

export function Sidebar() {
  const path = usePathname();
  const { count } = useCart();
  return (
    <nav id="sidebar" className="sidebar" aria-label="القائمة الرئيسية">
      {LIVE.map(([href, icon, label]) => {
        const p = href.split('?')[0], active = href.includes('?') ? false : p === '/' ? path === '/' : path === p || path.startsWith(p + '/');
        return <Link key={href} href={href} title={label} className={active ? 'active' : undefined}><Icon name={icon} /><span>{label}</span>{href === '/cart' && count > 0 && <b>{count}</b>}</Link>;
      })}
      <hr />
      {SOON.map(([icon, label]) => <a key={label} aria-disabled="true" role="link" tabIndex={-1} title={`${label} — قيد التنفيذ (يحتاج الخادم)`} style={{ opacity: 0.45, cursor: 'not-allowed' }}><Icon name={icon} /><span>{label}</span></a>)}
    </nav>
  );
}

export function HomeBack() {
  const path = usePathname();
  return <Link id="homeBack" className="homeback" href="/" hidden={path === '/'}><Icon name="home" /><span>رجوع للرئيسية</span></Link>;
}
