'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { CART_KEY, addItem, cartCount, changeQty, parseStoredCart, removeItem, type CartItem } from '../lib/cart';
import { stockOf } from '../lib/storefront';
import { Icon } from './Icon';

interface Ctx { cart: CartItem[]; loaded: boolean; count: number; add: (i: CartItem) => boolean; change: (key: string, d: number) => void; remove: (key: string) => void; clear: () => void; toast: (m: string, t?: 'ok' | 'err') => void }
const CartCtx = createContext<Ctx | null>(null);
export const useCart = (): Ctx => { const c = useContext(CartCtx); if (!c) throw new Error('useCart outside CartProvider'); return c; };

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [msg, setMsg] = useState<{ text: string; type: 'ok' | 'err' } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { try { setCart(parseStoredCart(localStorage.getItem(CART_KEY))); } catch { /* storage blocked */ } setLoaded(true); }, []);
  useEffect(() => { const sync = (e: StorageEvent) => { if (e.key === CART_KEY) setCart(parseStoredCart(e.newValue)); }; window.addEventListener('storage', sync); return () => window.removeEventListener('storage', sync); }, []);
  const persist = useCallback((next: CartItem[]) => { setCart(next); try { localStorage.setItem(CART_KEY, JSON.stringify(next)); } catch { /* ignore */ } }, []);
  const toast = useCallback((text: string, type: 'ok' | 'err' = 'ok') => { setMsg({ text, type }); if (timer.current) clearTimeout(timer.current); timer.current = setTimeout(() => setMsg(null), 3500); }, []);

  const value = useMemo<Ctx>(() => ({
    cart, loaded, count: cartCount(cart), toast,
    add: (i) => { const r = addItem(cart, i, stockOf); if (r.error) { toast(r.error, 'err'); return false; } persist(r.cart); toast('أُضيف إلى السلة.'); return true; },
    change: (key, d) => { const r = changeQty(cart, key, d, stockOf); if (r.error) toast(r.error, 'err'); else persist(r.cart); },
    remove: (key) => persist(removeItem(cart, key)),
    clear: () => persist([]),
  }), [cart, loaded, persist, toast]);

  return (
    <CartCtx.Provider value={value}>
      {children}
      <div id="toast" className={`toast ${msg?.type ?? 'ok'}`} role="status" aria-live="polite" hidden={!msg}>{msg && <><Icon name={msg.type === 'ok' ? 'check' : 'x'} /> {msg.text}</>}</div>
    </CartCtx.Provider>
  );
}
