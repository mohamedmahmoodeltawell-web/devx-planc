import Link from 'next/link';
import { categories, products } from '../../lib/catalog';
import { Icon } from '../../components/Icon';
export const metadata = { title: 'الأقسام — Dev-X Book Store' };
const COVER: Record<string, string> = { books: 'b1', tshirts: 't4', notebooks: 'n1', other: 'o5' };
export default function Categories() {
  return (
    <>
      <h1>أقسام المتجر</h1>
      <div className="grid cats">{categories.map((c) => {
        const cover = products.find((p) => p.id === COVER[c.id]) ?? products.find((p) => p.category === c.id);
        return <Link key={c.id} className="cat" href={`/category/${c.id}`}>{cover ? <span className="ico ph">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={cover.images[0]} alt="" loading="lazy" /></span> : <span className="ico"><Icon name={c.id} /></span>}<span>{c.name}<small>{products.filter((p) => p.category === c.id).length} منتج</small></span></Link>;
      })}</div>
      <div className="bot" id="bot">
        <div className="bot-msg"><span className="tag">Dev-X</span><h2>مستقبلك بيبدأ من هنا</h2><p>اتعلّم البرمجة والذكاء الاصطناعي بخطوات بسيطة، وكل كتاب بياخد بإيدك خطوة لقدّام.</p><Link className="bot-btn" href="/category/books">تصفّح الكتب</Link></div>
        <div className="bot-fig"><div className="bot-in" id="botIn">{/* eslint-disable-next-line @next/next/no-img-element */}<img className="botimg" src="/brand/botimg.jpg" alt="" /></div></div>
      </div>
    </>
  );
}
