import Link from 'next/link';
import { categories, isAvailable, products, searchProducts, tiers } from '../lib/catalog';
import { formatPriceAr } from '../lib/money';
import { HeroScene } from '../components/HeroScene';
import { ProductGrid } from '../components/ProductCard';
import { Icon } from '../components/Icon';

const COVER: Record<string, string> = { books: 'b1', tshirts: 't4', notebooks: 'n1', other: 'o5' };

export default function Home() {
  const newest = searchProducts(products, { sort: 'newest' });
  const offers = newest.filter((p) => p.salePrice != null && isAvailable(p)).slice(0, 8);
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <h1>كل اللي محتاجه للتعلّم في مكان واحد</h1>
          <p>كتب، تيشرتات، نوت بوك ومنتجات متنوعة لعشاق التعلّم والتقنية من Dev-X Book Store.</p>
          <div className="actions">
            <Link className="btn cta main" href="/categories"><Icon name="grid" /><span>تسوّق دلوقتي</span></Link>
            <Link className="btn cta alt" href="/search?offers=1"><Icon name="tag" /><span>العروض والخصومات</span></Link>
          </div>
        </div>
        <HeroScene />
      </section>
      <div className="strip"><b>خصم على إجمالي طلبك:</b> {[...tiers].sort((a, b) => a.min - b.min).map((t) => <span className="chip" key={t.min}><em>{t.rate}٪</em> من {formatPriceAr(t.min)}</span>)}</div>
      <div className="sec-head"><h2>الأقسام</h2></div>
      <div className="grid cats">{categories.map((c) => {
        const cover = products.find((p) => p.id === COVER[c.id]) ?? products.find((p) => p.category === c.id);
        return <Link key={c.id} className="cat" href={`/category/${c.id}`}>{cover ? <span className="ico ph">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={cover.images[0]} alt="" loading="lazy" /></span> : <span className="ico"><Icon name={c.id} /></span>}<span>{c.name}</span></Link>;
      })}</div>
      {offers.length > 0 && <><div className="sec-head"><h2>العروض</h2><Link href="/search?offers=1">عرض الكل</Link></div><ProductGrid list={offers} /></>}
      <div className="sec-head"><h2>أحدث المنتجات</h2><Link href="/search?sort=newest">عرض الكل</Link></div>
      <ProductGrid list={newest.slice(0, 8)} />
    </>
  );
}
