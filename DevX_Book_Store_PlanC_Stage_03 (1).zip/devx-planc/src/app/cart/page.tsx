import { CartView } from '../../components/CartView';
export const metadata = { title: 'السلة — Dev-X Book Store' };
export default function CartPage() { return <><h1>السلة</h1><CartView /></>; }
