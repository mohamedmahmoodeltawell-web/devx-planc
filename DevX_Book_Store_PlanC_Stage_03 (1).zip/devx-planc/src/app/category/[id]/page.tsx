import { notFound } from 'next/navigation';
import { getCategory, products, searchProducts, SORTS, type SortKey } from '../../../lib/catalog';
import { Empty, ProductGrid } from '../../../components/ProductCard';

type P = { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> };
export async function generateMetadata({ params }: Pick<P, 'params'>) { const c = getCategory((await params).id); return { title: `${c?.name ?? 'القسم'} — Dev-X Book Store` }; }

export default async function CategoryPage({ params, searchParams }: P) {
  const c = getCategory((await params).id);
  if (!c) notFound();
  const sp = await searchParams, s = Array.isArray(sp.sort) ? sp.sort[0] : sp.sort;
  const sort = (SORTS.some(([k]) => k === s) ? s : '') as SortKey;
  const list = searchProducts(products, { category: c.id, sort });
  return (
    <>
      <h1>{c.name}</h1>
      <form className="filters" action="" method="get"><div><label htmlFor="s">الترتيب</label><select id="s" name="sort" defaultValue={sort}>{SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div><button className="btn" type="submit">تطبيق</button></form>
      {list.length ? <ProductGrid list={list} /> : <Empty title="لا توجد منتجات في هذا القسم" text="سيتم إضافة منتجات قريبًا." href="/categories" action="كل الأقسام" />}
    </>
  );
}
