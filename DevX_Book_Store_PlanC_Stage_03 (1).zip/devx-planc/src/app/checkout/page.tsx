import { CheckoutForm } from '../../components/CheckoutForm';
export const metadata = { title: 'إتمام الطلب — Dev-X Book Store' };
export default function Page() { return <CheckoutForm />; }
