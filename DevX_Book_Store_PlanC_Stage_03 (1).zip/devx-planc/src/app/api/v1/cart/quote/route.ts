import { handle, ok, readJson, assertSameOrigin } from "@/server/http";
import { buildQuote } from "@/server/orders/createOrder";
import { readStore } from "@/server/orders/prismaStore";
import { parseQuote } from "@/server/validate";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Server-side price quote. The client never supplies prices or totals. */
export const POST = handle(async (req: Request) => {
  assertSameOrigin(req);
  const b = parseQuote(await readJson(req));
  const { q } = await buildQuote(readStore(), b.items, b.couponCode, b.deliveryMethod);
  return ok({ quote: q });
});
