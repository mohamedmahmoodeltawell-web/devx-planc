import { assertSameOrigin, handle, ok } from "@/server/http";
import { clearSessionCookie } from "@/server/auth/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request) => {
  assertSameOrigin(req);
  return ok({}, { headers: { "Set-Cookie": clearSessionCookie() } });
});
