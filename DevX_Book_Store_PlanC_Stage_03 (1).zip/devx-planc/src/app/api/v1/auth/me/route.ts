import { getUser } from "@/server/auth/guard";
import { handle, ok } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = handle(async (req: Request) => ok({ user: await getUser(req) }));
