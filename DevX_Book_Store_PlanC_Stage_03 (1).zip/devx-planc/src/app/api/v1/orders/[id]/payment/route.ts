import { prisma } from "@/lib/prisma";
import { requireUser } from "@/server/auth/guard";
import { assertSameOrigin, handle, ok, readJson, HttpError } from "@/server/http";
import { MANUAL_REFERENCE_METHODS } from "@/server/orders/rules";
import { parsePaymentReference } from "@/server/validate";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Customer submits a transfer reference. This NEVER marks the order paid: it moves it to PENDING_REVIEW for an admin to verify. */
export const POST = handle(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const user = await requireUser(req);
  const { id } = await ctx.params;
  const b = parsePaymentReference(await readJson(req));
  const order = await prisma.order.findFirst({ where: { id, userId: user.id } });
  if (!order) throw new HttpError(404, "not_found", "الطلب غير موجود.");
  if (!MANUAL_REFERENCE_METHODS.includes(order.paymentMethod)) throw new HttpError(422, "not_manual", "وسيلة الدفع لا تدعم إدخال مرجع تحويل.");
  if (order.status === "CANCELLED" || order.paymentStatus === "PAID") throw new HttpError(409, "not_payable", "لا يمكن إضافة دفعة لهذا الطلب.");
  try {
    await prisma.$transaction([
      prisma.paymentAttempt.create({ data: { orderId: order.id, method: order.paymentMethod, reference: b.reference, senderPhone: b.senderPhone, amount: order.total } }),
      prisma.order.update({ where: { id: order.id }, data: { paymentStatus: "PENDING_REVIEW" } }),
    ]);
  } catch (e) {
    if ((e as { code?: string }).code === "P2002") throw new HttpError(409, "reference_used", "هذا المرجع مستخدم من قبل.");
    throw e;
  }
  return ok({ paymentStatus: "PENDING_REVIEW" }, { status: 201 });
});
