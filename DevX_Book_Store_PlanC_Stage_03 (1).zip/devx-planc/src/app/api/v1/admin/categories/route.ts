import { prisma } from "@/lib/prisma";
import { requireRole } from "@/server/auth/guard";
import { assertSameOrigin, handle, ok, readJson, HttpError } from "@/server/http";
import { audit } from "@/server/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const POST = handle(async (req: Request) => {
  assertSameOrigin(req);
  const actor = await requireRole(req, ["ADMIN"]);
  const b = (await readJson(req)) as { id?: unknown; name?: unknown; sort?: unknown };
  if (typeof b.id !== "string" || !/^[a-z0-9-]{2,40}$/.test(b.id) || typeof b.name !== "string" || b.name.trim().length < 2 || b.name.length > 80) throw new HttpError(400, "validation", "بيانات غير صحيحة.");
  const sort = Number.isInteger(b.sort) ? (b.sort as number) : 0;
  try {
    await prisma.$transaction(async (tx) => { await tx.category.create({ data: { id: b.id as string, name: (b.name as string).trim(), sort } }); await audit(tx, actor.id, "category.create", "Category", b.id as string, null, { name: b.name }); });
  } catch (e) { if ((e as { code?: string }).code === "P2002") throw new HttpError(409, "duplicate", "التصنيف موجود."); throw e; }
  return ok({}, { status: 201 });
});
