import { prisma } from "@/lib/prisma";
import { requireRole } from "@/server/auth/guard";
import { handle, ok } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const STATUSES = ["CONFIRMED", "PREPARING", "OUT_FOR_DELIVERY", "READY_FOR_PICKUP", "DELIVERED", "CANCELLED"];
const PAY = ["AWAITING_PAYMENT", "PENDING_REVIEW", "PAID"];

export const GET = handle(async (req: Request) => {
  await requireRole(req, ["ADMIN", "STAFF"]);
  const sp = new URL(req.url).searchParams;
  const status = STATUSES.find((s) => s === sp.get("status")), paymentStatus = PAY.find((s) => s === sp.get("paymentStatus"));
  const page = Math.max(1, Math.floor(Number(sp.get("page") ?? 1)) || 1);
  const where = { ...(status ? { status: status as never } : {}), ...(paymentStatus ? { paymentStatus: paymentStatus as never } : {}) };
  const [total, orders] = await Promise.all([
    prisma.order.count({ where }),
    prisma.order.findMany({ where, orderBy: { createdAt: "desc" }, skip: (page - 1) * 30, take: 30,
      select: { id: true, number: true, customerName: true, customerPhone: true, status: true, paymentStatus: true, paymentMethod: true, deliveryMethod: true, total: true, createdAt: true } }),
  ]);
  return ok({ total, page, orders });
});
