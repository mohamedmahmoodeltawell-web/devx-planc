import { prisma } from "@/lib/prisma";
import { requireRole } from "@/server/auth/guard";
import { assertSameOrigin, handle, ok, readJson, HttpError } from "@/server/http";
import { parseProductPatch } from "@/server/validate";
import { audit } from "@/server/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Update price/sale/active/category and (optionally) variant stock: { ..., variants: [{ id, stock }] }. */
export const PATCH = handle(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const actor = await requireRole(req, ["ADMIN"]);
  const { id } = await ctx.params;
  const raw = (await readJson(req)) as { variants?: unknown } & Record<string, unknown>;
  const { variants, ...rest } = raw ?? {};
  const stock = Array.isArray(variants) ? variants.slice(0, 100).map((v) => ({ id: String((v as { id?: unknown })?.id ?? ""), stock: Number((v as { stock?: unknown })?.stock) })) : [];
  if (stock.some((v) => !v.id || !Number.isInteger(v.stock) || v.stock < 0 || v.stock > 100000)) throw new HttpError(400, "validation", "قيمة مخزون غير صحيحة.");
  const patch = Object.keys(rest).length || !stock.length ? parseProductPatch(rest) : {};
  await prisma.$transaction(async (tx) => {
    const before = await tx.product.findUnique({ where: { id }, select: { price: true, salePrice: true, active: true, name: true } });
    if (!before) throw new HttpError(404, "not_found", "المنتج غير موجود.");
    const price = patch.price ?? before.price, sale = patch.salePrice === undefined ? before.salePrice : patch.salePrice;
    if (sale != null && sale >= price) throw new HttpError(400, "validation", "سعر التخفيض يجب أن يكون أقل من السعر.");
    if (Object.keys(patch).length) await tx.product.update({ where: { id }, data: patch });
    for (const v of stock) { const r = await tx.productVariant.updateMany({ where: { id: v.id, productId: id }, data: { stock: v.stock } }); if (r.count !== 1) throw new HttpError(422, "variant_invalid", "متغير غير صحيح."); }
    await audit(tx, actor.id, "product.update", "Product", id, before, { ...patch, ...(stock.length ? { stock } : {}) });
  });
  return ok({});
});
