import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getCategory, getProduct } from '../../../lib/catalog';
import { AddToCart } from '../../../components/AddToCart';

type P = { params: Promise<{ id: string }> };
export async function generateMetadata({ params }: P) { const p = getProduct((await params).id); return { title: p ? `${p.name} — Dev-X Book Store` : 'منتج — Dev-X Book Store' }; }

export default async function ProductPage({ params }: P) {
  const p = getProduct((await params).id);
  if (!p) notFound();
  const cat = getCategory(p.category);
  return (
    <div className="layout2">
      <div className="card"><div className="pimg big">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={p.images[0]} alt={p.name} style={{ width: '100%', height: 'auto', borderRadius: 12 }} /></div></div>
      <div className="card">
        {cat && <p className="muted"><Link href={`/category/${cat.id}`}>{cat.name}</Link></p>}
        <h1>{p.name}</h1>
        {p.description && <p>{p.description}</p>}
        <AddToCart product={p} />
      </div>
    </div>
  );
}
